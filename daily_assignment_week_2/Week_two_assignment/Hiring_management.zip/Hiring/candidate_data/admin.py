from django.contrib import admin
from . models import candidate_data
# Register your models here.

admin.site.register(candidate_data)